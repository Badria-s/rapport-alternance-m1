// describe('suite delay for DOM inspection', function () {
// 	it('should delay by 10 minutes', function (done) {
// 		document.documentElement.style = 'background-color: #eee; height: 100%'
// 		const time = 1000 * 60 * 10 * 6
// 		this.timeout(time)
// 		setTimeout(done, time - 500)
// 	})
// })
